#ifndef SCANGPU_H
#define SCANGPU_H

// Scans for an Intel GPU, maps its MMIO space, and dumps basic control registers.
void gpu_scan_intel();

#endif