#ifndef SYSCALLS_H
#define SYSCALLS_H

#include <cstdint>

// Syscall Numbers
#define SYS_EXIT    0
#define SYS_PRINT   1
#define SYS_GETCH   2
#define SYS_DRAW    3
#define SYS_SLEEP   4

// Arguments passed via Registers:
// RAX = Syscall Number
// RDI = Arg1
// RSI = Arg2
// RDX = Arg3

#endif