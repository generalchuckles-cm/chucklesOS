#include "syscalls.h"
#include "../cppstd/stdio.h"
#include "../input.h"
#include "../render.h"
#include "../globals.h"
#include "../timer.h"
#include "../io.h"

// Defined in interrupts.asm
extern "C" void restore_kernel_stack();

extern "C" void cpp_syscall_handler(uint64_t syscall_id, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    switch (syscall_id) {
        case SYS_EXIT:
            // CRITICAL FIX: Re-enable interrupts before returning to the kernel.
            sti(); 
            
            // This restores RSP and RETs back into the ElfLoader::load_and_run function.
            restore_kernel_stack();
            break;

        case SYS_PRINT:
            // Arg1: const char* str
            // Arg2: Value 1 (optional)
            // Arg3: Value 2 (optional)
            if (arg1) {
                const char* str = (const char*)arg1;
                // If the pointer looks valid (higher half kernel space is where mapped usually,
                // but user space is lower half. 0x400000+ is valid).
                
                // Call kernel printf which can handle %d/%x formatting
                printf(str, arg2, arg3);
            }
            break;

        case SYS_GETCH:
            // Returns char in RAX
            {
                char c = input_get_char();
                asm volatile("mov %0, %%rax" :: "r"((uint64_t)c));
            }
            break;

        case SYS_DRAW:
            // Arg1: x, Arg2: y, Arg3: color
            if (g_renderer) g_renderer->putPixel(arg1, arg2, arg3);
            break;

        case SYS_SLEEP:
            // Arg1: ms
            sleep_ms(arg1);
            break;

        default:
            printf("SYSCALL: Unknown ID %d\n", (int)syscall_id);
            break;
    }
}