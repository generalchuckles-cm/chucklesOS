#include "text_editor.h"
#include "../globals.h"
#include "../input.h"
#include "../fs/fat32.h"
#include "../memory/heap.h"
#include "../cppstd/string.h"
#include "../cppstd/stdio.h"
#include "../timer.h"
#include "../io.h"

#define EDITOR_MAX_BUF 65536
#define STATUS_HEIGHT 16     

// --- Editor State ---
static bool g_editor_running = true;
static char* g_buffer = nullptr;
static uint32_t g_buf_len = 0;
static uint32_t g_cursor_pos = 0;
static char g_filename[32];
static bool g_dirty = false;

// Viewport state
static int g_scroll_line = 0;
static int g_screen_rows = 0;
static int g_screen_cols = 0;

// Syntax Colors
#define COL_DEFAULT   0xFFFFFF
#define COL_KEYWORD   0xFF00FF // Magenta
#define COL_TYPE      0x00FFFF // Cyan
#define COL_STRING    0x00FF00 // Green
#define COL_COMMENT   0x888888 // Grey
#define COL_NUMBER    0xFF8800 // Orange
#define COL_PREPROC   0xFFFF00 // Yellow

static bool is_keyword(const char* word, int len) {
    if (len == 2 && memcmp(word, "if", 2) == 0) return true;
    if (len == 4 && memcmp(word, "else", 4) == 0) return true;
    if (len == 5 && memcmp(word, "while", 5) == 0) return true;
    if (len == 6 && memcmp(word, "return", 6) == 0) return true;
    if (len == 3 && memcmp(word, "for", 3) == 0) return true;
    return false;
}

static bool is_type(const char* word, int len) {
    if (len == 3 && memcmp(word, "int", 3) == 0) return true;
    if (len == 4 && memcmp(word, "char", 4) == 0) return true;
    if (len == 4 && memcmp(word, "void", 4) == 0) return true;
    return false;
}

static void save_file() {
    if (Fat32::getInstance().write_file(g_filename, g_buffer, g_buf_len)) {
        g_dirty = false;
        // Draw status directly to renderer, bypassing console which might be window-bound
        g_renderer->drawRect(0, g_screen_rows * 16, g_renderer->getWidth(), 16, 0x333333);
        g_renderer->drawString(0, g_screen_rows * 16, " [SAVED]", 0x00FF00);
        sleep_ms(500);
    } else {
        g_renderer->drawRect(0, g_screen_rows * 16, g_renderer->getWidth(), 16, 0x333333);
        g_renderer->drawString(0, g_screen_rows * 16, " [ERROR SAVING]", 0x0000FF);
        sleep_ms(500);
    }
}

static void process_key(char c) {
    if (c == 27) { // ESC
        g_editor_running = false;
        return;
    }

    if (g_ctrl_pressed) {
        if (c == 's' || c == 'S' || c == 19) { 
            save_file();
            return;
        }
    }

    if (c == (char)KEY_LEFT) {
        if (g_cursor_pos > 0) g_cursor_pos--;
        return;
    }
    
    if (c == (char)KEY_RIGHT) {
        if (g_cursor_pos < g_buf_len) g_cursor_pos++;
        return;
    }

    if (c == (char)KEY_UP) {
        int curr = g_cursor_pos;
        int col = 0;
        while (curr > 0 && g_buffer[curr-1] != '\n') { curr--; col++; }
        
        if (curr > 0) {
            curr--; 
            while (curr > 0 && g_buffer[curr-1] != '\n') curr--;
            
            int line_len = 0;
            int temp = curr;
            while (temp < (int)g_buf_len && g_buffer[temp] != '\n') { temp++; line_len++; }
            
            if (col > line_len) col = line_len;
            g_cursor_pos = curr + col;
        }
        return;
    }

    if (c == (char)KEY_DOWN) {
        int curr = g_cursor_pos;
        while (curr < (int)g_buf_len && g_buffer[curr] != '\n') curr++;
        
        if (curr < (int)g_buf_len) {
            int col = 0;
            int temp = g_cursor_pos;
            while (temp > 0 && g_buffer[temp-1] != '\n') { temp--; col++; }

            curr++; 
            int next_start = curr;
            int line_len = 0;
            while (curr < (int)g_buf_len && g_buffer[curr] != '\n') { curr++; line_len++; }
            
            if (col > line_len) col = line_len;
            g_cursor_pos = next_start + col;
        }
        return;
    }

    if (c == '\b') {
        if (g_cursor_pos > 0) {
            memmove(g_buffer + g_cursor_pos - 1, g_buffer + g_cursor_pos, g_buf_len - g_cursor_pos);
            g_buf_len--;
            g_cursor_pos--;
            g_dirty = true;
        }
        return;
    }

    if (c >= 32 || c == '\n') {
        if (g_buf_len < EDITOR_MAX_BUF - 1) {
            memmove(g_buffer + g_cursor_pos + 1, g_buffer + g_cursor_pos, g_buf_len - g_cursor_pos);
            g_buffer[g_cursor_pos] = c;
            g_cursor_pos++;
            g_buf_len++;
            g_dirty = true;
        }
    }
}

static void render_editor() {
    int current_line = 0;
    for (uint32_t i = 0; i < g_cursor_pos; i++) {
        if (g_buffer[i] == '\n') current_line++;
    }
    
    if (current_line < g_scroll_line) g_scroll_line = current_line;
    if (current_line >= g_scroll_line + g_screen_rows) g_scroll_line = current_line - g_screen_rows + 1;

    g_renderer->clear(0x111111); 

    int draw_y = 0;
    int draw_x = 0;
    uint32_t i = 0;
    
    int skip = g_scroll_line;
    while (skip > 0 && i < g_buf_len) {
        if (g_buffer[i] == '\n') skip--;
        i++;
    }

    bool in_string = false;
    bool in_comment = false;
    bool in_preproc = false;

    while (i < g_buf_len && draw_y < g_screen_rows) {
        char c = g_buffer[i];
        
        uint32_t col = COL_DEFAULT;

        if (in_comment) col = COL_COMMENT;
        else if (in_string) col = COL_STRING;
        else if (in_preproc) col = COL_PREPROC;
        else {
            if (c >= '0' && c <= '9') col = COL_NUMBER;
            else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                bool start_word = (i == 0 || !((g_buffer[i-1] >= 'a' && g_buffer[i-1] <= 'z') || (g_buffer[i-1] >= 'A' && g_buffer[i-1] <= 'Z') || g_buffer[i-1] == '_'));
                if (start_word) {
                    int len = 0;
                    while (i+len < g_buf_len) {
                        char nc = g_buffer[i+len];
                        if (!((nc >= 'a' && nc <= 'z') || (nc >= 'A' && nc <= 'Z') || nc == '_')) break;
                        len++;
                    }
                    if (is_keyword(&g_buffer[i], len)) col = COL_KEYWORD;
                    else if (is_type(&g_buffer[i], len)) col = COL_TYPE;
                }
            }
        }

        if (c == '"' && !in_comment && !in_preproc) {
            in_string = !in_string;
            col = COL_STRING; 
        }
        if (c == '/' && i+1 < g_buf_len && g_buffer[i+1] == '/' && !in_string) {
            in_comment = true;
            col = COL_COMMENT;
        }
        if (c == '#' && !in_string && !in_comment) {
            in_preproc = true;
            col = COL_PREPROC;
        }
        if (c == '\n') {
            in_comment = false;
            in_preproc = false;
            in_string = false; 
            
            draw_y++;
            draw_x = 0;
            
            char lnbuf[8];
            int abs_line = g_scroll_line + draw_y;
            sprintf(lnbuf, "%3d ", abs_line);
            g_renderer->drawString(0, draw_y * 16, lnbuf, 0x444444);
            draw_x = 4;
        } else {
            g_renderer->drawChar(draw_x * 8, draw_y * 16, c, col);
            draw_x++;
        }
        i++;
    }

    int col_on_line = 0;
    int temp = g_cursor_pos;
    while (temp > 0 && g_buffer[temp-1] != '\n') { temp--; col_on_line++; }
    
    int rel_y = current_line - g_scroll_line;
    if (rel_y >= 0 && rel_y < g_screen_rows) {
        g_renderer->drawRect((col_on_line + 4) * 8, rel_y * 16 + 14, 8, 2, 0x00FF00); 
    }

    int status_y_char = g_screen_rows;
    char status[128];
    sprintf(status, " %s %s | Ln %d Col %d | Size %d | Ctrl+S: Save | ESC: Exit ", 
        g_filename, g_dirty ? "*" : "", current_line + 1, col_on_line + 1, (int)g_buf_len);
    
    // CHANGED: Use g_renderer directly instead of g_console to ensure it's visible on the active screen
    g_renderer->drawRect(0, status_y_char * 16, g_renderer->getWidth(), 16, 0x333333);
    g_renderer->drawString(0, status_y_char * 16, status, 0xFFFFFF);
}

void run_text_editor(const char* filename) {
    g_editor_running = true;
    g_dirty = false;
    g_scroll_line = 0;
    strcpy(g_filename, filename);

    g_screen_cols = g_renderer->getWidth() / 8;
    g_screen_rows = (g_renderer->getHeight() / 16) - 1;

    g_buffer = (char*)malloc(EDITOR_MAX_BUF);
    if (!g_buffer) {
        printf("Editor: OOM\n");
        return;
    }
    memset(g_buffer, 0, EDITOR_MAX_BUF);
    g_buf_len = 0;
    g_cursor_pos = 0;

    if (Fat32::getInstance().read_file(filename, g_buffer, EDITOR_MAX_BUF)) {
        g_buf_len = 0;
        while (g_buf_len < EDITOR_MAX_BUF && g_buffer[g_buf_len] != 0) g_buf_len++;
        printf("Editor: Loaded %d bytes.\n", (int)g_buf_len);
    } else {
        printf("Editor: New File.\n");
    }
    
    sleep_ms(500);

    render_editor(); // Initial Draw

    while (g_editor_running) {
        char c = input_check_char();
        if (c != 0) {
            process_key(c);
            render_editor();
        } else {
            check_input_hooks();
            asm volatile("hlt");
        }
    }

    free(g_buffer);
    if (g_renderer) g_renderer->clear(0x000000);
}