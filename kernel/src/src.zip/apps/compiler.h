#ifndef COMPILER_H
#define COMPILER_H

void run_compiler(const char* source_file, const char* out_file);

#endif