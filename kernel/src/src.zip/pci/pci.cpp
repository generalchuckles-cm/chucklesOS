#include "pci.h"

// Implementation moved to header to fix linking issues.