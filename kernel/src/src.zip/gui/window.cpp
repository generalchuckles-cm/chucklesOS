#include "window.h"
#include "../memory/heap.h"
#include "../cppstd/string.h"
#include "../cppstd/stdio.h"
#include "../input.h"
#include "../globals.h"

// --- Window Implementation ---

Window::Window(int x, int y, int w, int h, const char* t, WindowApp* a) 
    : x(x), y(y), width(w), height(h), app(a), should_close(false), 
      is_focused(false), is_dragging(false) {
    
    strcpy(title, t);
    
    // 1. Allocate Private Buffer
    backing_buffer = (uint32_t*)malloc(width * height * 4);
    if (backing_buffer) memset(backing_buffer, 0, width * height * 4);
    
    // 2. Create Virtual Framebuffer Struct
    limine_framebuffer* vfb = (limine_framebuffer*)malloc(sizeof(limine_framebuffer));
    vfb->address = backing_buffer;
    vfb->width = width;
    vfb->height = height;
    vfb->pitch = width * 4;
    vfb->bpp = 32;
    
    // 3. Create Renderer and Console for this window
    extern const uint8_t g_zap_font[]; 
    renderer = new Renderer(vfb, g_zap_font);
    console = new Console(renderer);
    
    if (app) app->on_init(this);
}

Window::~Window() {
    if (console) delete console;
    if (renderer) delete renderer;
    if (backing_buffer) free(backing_buffer);
    if (app) delete app;
}

void Window::render_frame(Renderer* r) {
    if (!backing_buffer) return;

    // 1. Draw Title Bar (Blue)
    uint32_t bar_color = is_focused ? 0x0000AA : 0x444444;
    r->drawRect(x, y - 20, width, 20, bar_color);
    
    // 2. Draw Title Text
    r->drawString(x + 4, y - 16, title, 0xFFFFFF);
    
    // 3. Draw Close Button (Red Square)
    int btn_size = 16;
    int btn_x = x + width - btn_size - 2;
    int btn_y = y - 18;
    r->drawRect(btn_x, btn_y, btn_size, btn_size, 0xFF0000);
    r->drawChar(btn_x + 4, btn_y, 'X', 0xFFFFFF);
    
    // 4. Blit the Content Buffer
    r->renderBitmap32(x, y, width, height, backing_buffer);
    
    // 5. Draw Border
    uint32_t border = is_focused ? 0x00FFFF : 0x444444;
    r->drawRect(x - 1, y, 1, height, border); 
    r->drawRect(x + width, y, 1, height, border); 
    r->drawRect(x - 1, y + height, width + 2, 1, border); 
}

void Window::handle_mouse(int mx, int my, bool left) {
    if (left && !is_dragging) {
        if (mx >= x && mx <= x + width && my >= y - 20 && my <= y) {
            int btn_x = x + width - 18;
            if (mx >= btn_x) {
                should_close = true;
                return;
            }
            is_dragging = true;
            drag_offset_x = mx - x;
            drag_offset_y = my - y;
        }
    }
    
    if (!left) {
        is_dragging = false;
    }
    
    if (is_dragging) {
        x = mx - drag_offset_x;
        y = my - drag_offset_y;
    }
}

void Window::handle_keyboard(char c) {
    if (app) app->on_input(c);
}

// --- Window Manager Implementation ---

const uint8_t WindowManager::cursor_bitmap[] = {
    1,1,0,0,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,2,2,1,0,0,0,0,0,0,
    1,2,2,2,2,2,1,0,0,0,0,0,
    1,2,2,2,2,2,2,1,0,0,0,0,
    1,2,2,2,2,2,2,2,1,0,0,0,
    1,2,2,2,2,2,2,2,2,1,0,0,
    1,2,2,2,2,2,2,2,2,2,1,0,
    1,2,2,2,2,2,1,1,1,1,1,1,
    1,2,2,2,1,2,1,0,0,0,0,0,
    1,2,2,1,0,1,2,1,0,0,0,0,
    1,2,1,0,0,1,2,1,0,0,0,0,
    1,1,0,0,0,0,1,2,1,0,0,0,
    0,0,0,0,0,0,1,2,1,0,0,0,
    0,0,0,0,0,0,0,1,1,0,0,0
};

WindowManager& WindowManager::getInstance() {
    static WindowManager instance;
    return instance;
}

WindowManager::WindowManager() : window_count(0), focused_index(-1), backbuffer(nullptr) {}

void WindowManager::init(int w, int h) {
    window_count = 0;
    focused_index = -1;
    screen_width = w;
    screen_height = h;
    
    // Allocate Double Buffer
    backbuffer = (uint32_t*)malloc(w * h * 4);
    if (!backbuffer) {
        // Panic or handle error
    }
    memset(backbuffer, 0, w * h * 4);

    if (g_renderer) {
        g_mouse_x = w / 2;
        g_mouse_y = h / 2;
    }
}

void WindowManager::add_window(Window* win) {
    if (window_count < MAX_WINDOWS) {
        windows[window_count++] = win;
        focused_index = window_count - 1;
    }
}

Console* WindowManager::get_focused_console() {
    if (focused_index >= 0 && focused_index < window_count) {
        return windows[focused_index]->console;
    }
    return nullptr;
}

void WindowManager::update() {
    bool left = g_mouse_left;
    
    // Focus Logic
    if (left && !last_mouse_left) {
        for (int i = window_count - 1; i >= 0; i--) {
            Window* w = windows[i];
            if (g_mouse_x >= w->x && g_mouse_x <= w->x + w->width &&
                g_mouse_y >= w->y - 20 && g_mouse_y <= w->y + w->height) {
                
                focused_index = i;
                if (i != window_count - 1) {
                    Window* temp = windows[window_count - 1];
                    windows[window_count - 1] = w;
                    windows[i] = temp;
                    focused_index = window_count - 1;
                }
                break;
            }
        }
    }
    
    for(int i=0; i<window_count; i++) windows[i]->is_focused = (i == focused_index);

    if (focused_index >= 0) {
        windows[focused_index]->handle_mouse(g_mouse_x, g_mouse_y, left);
    }
    
    if (focused_index >= 0 && windows[focused_index]->should_close) {
        Window* dead = windows[focused_index];
        for (int i = focused_index; i < window_count - 1; i++) {
            windows[i] = windows[i+1];
        }
        window_count--;
        if (window_count > 0) focused_index = window_count - 1;
        else focused_index = -1;
        
        delete dead;
    }

    last_mouse_left = left;

    char c = input_check_char();
    if (c != 0) {
        if (focused_index >= 0) {
            windows[focused_index]->handle_keyboard(c);
        }
    }
}

void WindowManager::render(Renderer* global_renderer) {
    if (!backbuffer) return;

    // 1. Create a temporary Renderer bound to the Backbuffer
    limine_framebuffer virtual_fb = {
        .address = backbuffer,
        .width = (uint64_t)screen_width,
        .height = (uint64_t)screen_height,
        .pitch = (uint64_t)screen_width * 4,
        .bpp = 32
    };
    extern const uint8_t g_zap_font[];
    Renderer offscreen(&virtual_fb, g_zap_font);

    // 2. Clear Backbuffer
    offscreen.clear(0x000000);
    
    // 3. Draw Windows to Backbuffer
    for (int i = 0; i < window_count; i++) {
        windows[i]->render_frame(&offscreen);
    }
    
    // 4. Draw Mouse Cursor to Backbuffer
    int mx = g_mouse_x;
    int my = g_mouse_y;
    
    for (int y = 0; y < CURSOR_H; y++) {
        if (my + y >= screen_height) break;
        for (int x = 0; x < CURSOR_W; x++) {
            if (mx + x >= screen_width) break;
            
            uint8_t p = cursor_bitmap[y * CURSOR_W + x];
            if (p == 1) backbuffer[(my + y) * screen_width + (mx + x)] = 0x000000;
            else if (p == 2) backbuffer[(my + y) * screen_width + (mx + x)] = 0xFFFFFF;
        }
    }

    // 5. Flip Buffer (Copy Backbuffer to VRAM)
    // Using renderBitmap32 is fast enough if SSE is enabled
    global_renderer->renderBitmap32(0, 0, screen_width, screen_height, backbuffer);
}