#include "high_loader.h"
#include "../fs/fat32.h"
#include "../memory/pmm.h"
#include "../memory/vmm.h"
#include "../memory/heap.h"
#include "../cppstd/stdio.h"
#include "../cppstd/string.h"

// Defined in interrupts.asm
extern "C" void jump_to_user_program(uint64_t entry, uint64_t argc, uint64_t argv, uint64_t stack_top);

void HighLoader::load_and_run(const char* filename) {
    printf("LOADER: High-Load request for %s\n", filename);

    // 1. Read file into temporary kernel buffer
    uint32_t file_size = 64 * 1024; // Limit to 64KB for now
    uint8_t* temp_buf = (uint8_t*)malloc(file_size);
    if (!Fat32::getInstance().read_file(filename, temp_buf, file_size)) {
        printf("LOADER: File not found.\n");
        free(temp_buf);
        return;
    }

    // Determine actual size
    uint32_t actual_size = 0;
    // Simple heuristic: CXE header or raw binary? 
    // The CCC compiler will output raw flat binaries for simplicity in this iteration.
    // We assume the file size read is accurate or we scan for nulls?
    // Fat32 read returns success but doesn't return size explicitly in our interface yet.
    // We will assume the compiler filled the buffer or we use strlen for text? 
    // No, binary. Let's assume it fits in the pages we allocate.
    actual_size = file_size; // Safe upper bound

    // 2. Calculate Top-Down Address
    uint64_t total_ram = pmm_get_total_memory();
    // Leave 1MB safety margin from very top (for BIOS/ACPI reclaim)
    uint64_t top_safe_ram = total_ram - (1024 * 1024); 
    
    // Calculate start address (Page Aligned)
    uint64_t load_phys = (top_safe_ram - actual_size) & ~0xFFF;
    
    // 3. Map this memory to Virtual Address (Identity mapped for simplicity or Fixed High)
    // We will map it to 0x40000000 (1GB mark) virtual, but backed by High Physical
    uint64_t virt_base = 0x40000000;
    uint32_t pages = (actual_size + 4095) / 4096;

    printf("LOADER: Loading at Phys 0x%lx -> Virt 0x%lx\n", load_phys, virt_base);

    for (uint32_t i = 0; i < pages; i++) {
        // Map page: User accessible, R/W/X
        vmm_map_page(virt_base + (i * 4096), load_phys + (i * 4096), PTE_PRESENT | PTE_RW | PTE_USER);
    }

    // 4. Copy Code to the physical location
    // We need a temporary kernel mapping to write to it
    // Or we rely on the HHDM (Higher Half Direct Map) to write to physical
    extern uint64_t g_hhdm_offset;
    void* write_ptr = (void*)(load_phys + g_hhdm_offset);
    memcpy(write_ptr, temp_buf, actual_size);
    
    free(temp_buf);

    // 5. Setup User Stack (Growing down from Virtual Base)
    // We map 4 pages below the code for stack
    uint64_t stack_top = virt_base; 
    uint64_t stack_bottom = stack_top - (4 * 4096);
    
    for (uint64_t addr = stack_bottom; addr < stack_top; addr += 4096) {
        void* s_phys = pmm_alloc(1);
        vmm_map_page(addr, (uint64_t)s_phys, PTE_PRESENT | PTE_RW | PTE_USER);
    }

    printf("LOADER: Launching...\n");
    
    // 6. Jump to 0x40000000 (Entry point of the raw binary)
    jump_to_user_program(virt_base, 0, 0, stack_top);
}