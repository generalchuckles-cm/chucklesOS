#ifndef SMP_H
#define SMP_H

// Initialize Symmetric Multiprocessing
// Wakes up APs using Limine.
void smp_init();

#endif