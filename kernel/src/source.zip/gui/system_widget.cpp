#include "system_widget.h"
#include "../render.h"           // Full definition of Renderer
#include "window.h"              // Full definition of Window
#include "../sys/system_stats.h" 
#include "../memory/pmm.h"
#include "../cppstd/stdio.h"
#include "../timer.h"

// Colors
#define WIDGET_BG       0xCC000000 
#define WIDGET_BORDER   0x00FF00   
#define TEXT_TITLE      0x00FF00
#define TEXT_NORMAL     0xFFFFFF
#define TEXT_WARN       0xFFFF00

void SystemWidget::render(Renderer* r, int screen_w) {
    // 1. Gather Data
    SystemStats& stats = SystemStats::getInstance();
    
    uint64_t total_ram = pmm_get_total_memory();
    uint64_t used_ram = pmm_get_used_memory();
    
    // 2. Calculate Layout
    int width = 220;
    int right_margin = 10;
    int top_margin = 10;
    int x = screen_w - width - right_margin;
    int y = top_margin;
    int line_h = 16;
    
    int height = 400; 
    
    // 3. Draw Container
    r->drawRect(x, y, width, height, 0x202020); 
    r->drawRect(x, y, width, 1, WIDGET_BORDER); // Top
    r->drawRect(x, y + height - 1, width, 1, WIDGET_BORDER); // Bottom
    r->drawRect(x, y, 1, height, WIDGET_BORDER); // Left
    r->drawRect(x + width - 1, y, 1, height, WIDGET_BORDER); // Right
    
    int cursor_y = y + 5;
    int cursor_x = x + 8;
    char buf[64];
    
    // --- SYSTEM RESOURCE HEADER ---
    r->drawString(cursor_x, cursor_y, "[ SYSTEM STATS ]", TEXT_TITLE);
    cursor_y += line_h + 5;
    
    // --- RAM ---
    sprintf(buf, "RAM: %d MB / %d MB", (int)(used_ram/1024/1024), (int)(total_ram/1024/1024));
    r->drawString(cursor_x, cursor_y, buf, TEXT_NORMAL);
    
    // Ram Bar
    cursor_y += line_h;
    int bar_w = width - 16;
    int fill_w = (int)((double)used_ram / (double)total_ram * bar_w);
    r->drawRect(cursor_x, cursor_y, bar_w, 4, 0x404040);
    r->drawRect(cursor_x, cursor_y, fill_w, 4, 0x00FF00);
    cursor_y += 10;
    
    // --- CPU CORES ---
    r->drawString(cursor_x, cursor_y, "--- CORES ---", 0xAAAAAA);
    cursor_y += line_h;
    
    for(int i=0; i<stats.cpu_count; i++) {
        const char* spinner = "|/-\\";
        uint64_t ticks = stats.cpu_ticks[i];
        char spin_char = spinner[(ticks / 1000) % 4]; 
        
        sprintf(buf, "CPU %d: %c Online", i, spin_char);
        r->drawString(cursor_x, cursor_y, buf, TEXT_NORMAL);
        cursor_y += line_h;
    }
    
    // --- SERVICES ---
    cursor_y += 5;
    r->drawString(cursor_x, cursor_y, "--- SERVICES ---", 0xAAAAAA);
    cursor_y += line_h;
    
    auto draw_srv = [&](const char* name, bool active) {
        sprintf(buf, "%s: %s", name, active ? "RUNNING" : "STOPPED");
        r->drawString(cursor_x, cursor_y, buf, active ? TEXT_NORMAL : 0x888888);
        cursor_y += line_h;
    };
    
    draw_srv("SMP Layer", stats.service_smp_active);
    draw_srv("PCI Bus", true); 
    draw_srv("PS/2 Input", stats.service_ps2_active);
    draw_srv("E1000 Net", stats.service_e1000_active);
    draw_srv("AHCI Disk", stats.service_ahci_active);
    draw_srv("xHCI USB", stats.service_xhci_active);
}

void SystemWidget::render_process_list(Renderer* r, int screen_w, Window** windows, int count) {
    int width = 220;
    int right_margin = 10;
    int top_margin = 10;
    int x = screen_w - width - right_margin;
    
    SystemStats& stats = SystemStats::getInstance();
    // Rough offset calculation to render below the stats
    int start_y = top_margin + 5 + 16 + 5 + 16 + 4 + 10 + 16 + (stats.cpu_count * 16) + 5 + 16 + (6 * 16);
    
    int cursor_x = x + 8;
    int cursor_y = start_y + 5;
    
    r->drawString(cursor_x, cursor_y, "--- PROCESSES ---", 0xAAAAAA);
    cursor_y += 16;
    
    for(int i=0; i<count; i++) {
        if(windows[i]) {
            char title_buf[24];
            const char* src = windows[i]->title;
            int j=0;
            while(src[j] && j < 20) { title_buf[j] = src[j]; j++; }
            title_buf[j] = 0;
            
            char line[64];
            sprintf(line, "[%d] %s", i, title_buf);
            
            uint32_t col = windows[i]->is_focused ? 0x00FFFF : TEXT_NORMAL;
            r->drawString(cursor_x, cursor_y, line, col);
            cursor_y += 16;
        }
    }
}