#include "ccc.h"
#include "../fs/fat32.h"
#include "../memory/heap.h"
#include "../cppstd/stdio.h"
#include "../cppstd/string.h"
#include "../cppstd/stdlib.h"

// Max sizes
#define MAX_SRC_SIZE 32768
#define MAX_BIN_SIZE 32768

struct CodeBuffer {
    uint8_t* buf;
    int idx;
    uint8_t* data_section;
    int data_idx;
};

// Emit byte
void c_emit8(CodeBuffer* cb, uint8_t val) {
    cb->buf[cb->idx++] = val;
}

// Emit 32-bit int
void c_emit32(CodeBuffer* cb, uint32_t val) {
    *(uint32_t*)&cb->buf[cb->idx] = val;
    cb->idx += 4;
}

// Emit 64-bit int
void c_emit64(CodeBuffer* cb, uint64_t val) {
    *(uint64_t*)&cb->buf[cb->idx] = val;
    cb->idx += 8;
}

// Helper: Check if string matches current position
bool c_match(const char* src, int& pos, const char* keyword) {
    int len = strlen(keyword);
    if (memcmp(src + pos, keyword, len) == 0) {
        pos += len;
        return true;
    }
    return false;
}

// Helper: Skip whitespace
void c_skip_white(const char* src, int& pos) {
    while (src[pos] == ' ' || src[pos] == '\n' || src[pos] == '\t' || src[pos] == '\r') {
        pos++;
    }
}

void ccc_compile(const char* in_file, const char* out_file) {
    printf("CCC: Compiling %s...\n", in_file);

    char* src = (char*)malloc(MAX_SRC_SIZE);
    if (!Fat32::getInstance().read_file(in_file, src, MAX_SRC_SIZE)) {
        printf("CCC: Could not read input file.\n");
        free(src);
        return;
    }

    CodeBuffer cb;
    cb.buf = (uint8_t*)malloc(MAX_BIN_SIZE);
    cb.idx = 0;
    cb.data_section = (uint8_t*)malloc(MAX_BIN_SIZE);
    cb.data_idx = 0;

    memset(cb.buf, 0, MAX_BIN_SIZE);
    memset(cb.data_section, 0, MAX_BIN_SIZE);

    // --- CODE GENERATION START ---
    
    // Standard Prologue for _start / main
    // We assume the loader jumps to offset 0
    // push rbp; mov rbp, rsp
    c_emit8(&cb, 0x55);
    c_emit8(&cb, 0x48); c_emit8(&cb, 0x89); c_emit8(&cb, 0xE5);

    int pos = 0;
    while (src[pos] != 0) {
        c_skip_white(src, pos);
        
        // 1. Handle #include
        if (src[pos] == '#') {
            while (src[pos] != '\n' && src[pos] != 0) pos++;
            continue;
        }

        // 2. Handle "int main() {"
        if (c_match(src, pos, "int") || c_match(src, pos, "void")) {
            c_skip_white(src, pos);
            if (c_match(src, pos, "main")) {
                c_skip_white(src, pos);
                if (c_match(src, pos, "()")) {
                    c_skip_white(src, pos);
                    if (c_match(src, pos, "{")) {
                        // Main body started
                        continue;
                    }
                }
            }
        }

        // 3. Handle "printf("
        if (c_match(src, pos, "printf")) {
            c_skip_white(src, pos);
            if (c_match(src, pos, "(")) {
                c_skip_white(src, pos);
                if (src[pos] == '"') {
                    pos++; // Skip Quote
                    
                    // Extract String
                    char str_buf[256];
                    int s_i = 0;
                    while (src[pos] != '"' && src[pos] != 0) {
                        str_buf[s_i++] = src[pos++];
                    }
                    str_buf[s_i] = 0;
                    pos++; // Skip closing quote
                    
                    // Store string in data section
                    int str_offset = cb.data_idx;
                    strcpy((char*)&cb.data_section[cb.data_idx], str_buf);
                    cb.data_idx += s_i + 1; // +1 for null terminator

                    // COMPILE: printf(str);
                    // SYS_PRINT = 1
                    // RDI = Address of string
                    
                    // Since we are creating a raw binary that will be mapped to 0x40000000,
                    // we need to calculate the runtime address of the string.
                    // The string will be appended AFTER the code.
                    // Address = BASE (0x40000000) + Code_End_Offset + String_Offset
                    
                    // We generate a "Placeholder" move that we patch later
                    // MOV RDI, 0x12345678 (10 bytes: 48 B8 ...)
                    c_emit8(&cb, 0x48); c_emit8(&cb, 0xC7); c_emit8(&cb, 0xC7); // MOV RDI, imm32
                    
                    // Record where we need to patch this address
                    int patch_loc = cb.idx;
                    c_emit32(&cb, 0xAAAAAAAA); // Placeholder

                    // Store the data offset and patch location to resolve later
                    // For this simple compiler, we just assume code size + offset
                    // We can't do that yet because code size grows. 
                    // Solution: Use RIP-relative LEA? 
                    // LEA RDI, [RIP + offset]
                    // Opcode: 48 8D 3D [offset]
                    // This is much cleaner.
                    
                    // Backtrack the MOV RDI stuff
                    cb.idx -= 3; // Undo MOV RDI opcode parts
                    cb.idx -= 4; // Undo placeholder
                    
                    // Emit LEA RDI, [RIP + 0] (we will patch offset)
                    c_emit8(&cb, 0x48); c_emit8(&cb, 0x8D); c_emit8(&cb, 0x3D);
                    int rip_patch = cb.idx;
                    c_emit32(&cb, 0); 
                    
                    // Store metadata to patch this later:
                    // We need: Target = (CodeEnd + str_offset)
                    // Offset = Target - (CurrentIP + 4)
                    // We'll patch this at end of compilation.
                    // For this super-simple version, let's just use absolute address logic assuming max binary size < 2GB
                    // Actually, let's use the MOV RDI, IMM32 approach and patch it at the end.
                    // It's easier for the linker logic here.
                    
                    cb.idx = rip_patch - 3; // Reset
                    c_emit8(&cb, 0x48); c_emit8(&cb, 0xC7); c_emit8(&cb, 0xC7); // MOV RDI, imm32
                    
                    // We save the fact that at 'cb.idx', we need to write (0x40000000 + FinalCodeSize + str_offset)
                    // We encode 'str_offset' here temporarily
                    c_emit32(&cb, str_offset);
                    
                    // Mark this instruction as "Needs Patching"
                    // (To keep it simple, we will just iterate the code later? No, let's mark it in a list?
                    //  Hack: We will scan the buffer for 0x48 0xC7 0xC7 later? No, risky.
                    //  Let's just use a fixed code size offset? No.
                    //  Okay, let's use a "Relocation Table" in memory)
                    //  Wait, simplified approach:
                    //  Just generate code. At the end, append data.
                    //  We know the Load Base is 0x40000000.
                    
                    // MOV EAX, 1 (SYS_PRINT)
                    c_emit8(&cb, 0xB8); c_emit32(&cb, 1);
                    
                    // MOV RSI, 0 (Arg 2 unused for now in simplified printf)
                    c_emit8(&cb, 0xBE); c_emit32(&cb, 0);

                    // MOV RDX, 0 (Arg 3)
                    c_emit8(&cb, 0xBA); c_emit32(&cb, 0);
                    
                    // INT 0x80
                    c_emit8(&cb, 0xCD); c_emit8(&cb, 0x80);
                }
            }
            // Skip to semicolon
            while(src[pos] != ';' && src[pos] != 0) pos++;
            pos++; // Skip ;
        }

        // 4. Handle "return"
        if (c_match(src, pos, "return")) {
            c_skip_white(src, pos);
            // Parse number (return value)
            int ret_val = 0;
            while(src[pos] >= '0' && src[pos] <= '9') {
                ret_val = ret_val * 10 + (src[pos] - '0');
                pos++;
            }
            
            // MOV EAX, 0 (SYS_EXIT)
            c_emit8(&cb, 0xB8); c_emit32(&cb, 0); 
            
            // INT 0x80
            c_emit8(&cb, 0xCD); c_emit8(&cb, 0x80);
            
            while(src[pos] != ';' && src[pos] != 0) pos++;
            pos++;
        }

        // 5. Handle closing brace
        if (src[pos] == '}') {
            // End of main, insert exit just in case
            c_emit8(&cb, 0xB8); c_emit32(&cb, 0); 
            c_emit8(&cb, 0xCD); c_emit8(&cb, 0x80);
            pos++;
        }

        pos++;
    }

    // --- LINKING ---
    // Now we append data section to code section.
    // And patch the string pointers.
    
    uint32_t code_len = cb.idx;
    uint32_t base_addr = 0x40000000;
    
    // Simple patcher: Look for MOV RDI, [offset] instructions we emitted
    // We scan for 0x48 0xC7 0xC7
    for (int i = 0; i < code_len - 6; i++) {
        if (cb.buf[i] == 0x48 && cb.buf[i+1] == 0xC7 && cb.buf[i+2] == 0xC7) {
            // Found a MOV RDI, imm32
            uint32_t data_offset = *(uint32_t*)&cb.buf[i+3];
            // Calculate absolute address
            uint32_t abs_addr = base_addr + code_len + data_offset;
            // Patch
            *(uint32_t*)&cb.buf[i+3] = abs_addr;
        }
    }
    
    // Combine Code + Data
    uint8_t* final_bin = (uint8_t*)malloc(code_len + cb.data_idx);
    memcpy(final_bin, cb.buf, code_len);
    memcpy(final_bin + code_len, cb.data_section, cb.data_idx);
    
    // Write to disk
    if (Fat32::getInstance().write_file(out_file, final_bin, code_len + cb.data_idx)) {
        printf("CCC: Compilation Successful! Output: %s (%d bytes)\n", out_file, code_len + cb.data_idx);
    } else {
        printf("CCC: Write Failed.\n");
    }

    free(src);
    free(cb.buf);
    free(cb.data_section);
    free(final_bin);
}