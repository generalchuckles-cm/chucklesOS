#ifndef CPL_COMPILER_H
#define CPL_COMPILER_H

void cpl_compile(const char* in_file, const char* out_file);

#endif