#ifndef MICROPYTHON_APP_H
#define MICROPYTHON_APP_H

void run_micropython();

#endif