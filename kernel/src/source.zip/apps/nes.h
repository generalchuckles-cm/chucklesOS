#ifndef NES_H
#define NES_H

#include "../gui/window.h"

class NESApp : public WindowApp {
public:
    NESApp(const char* filename);
    ~NESApp(); 

    void on_init(Window* win) override;
    void on_draw() override;
    void on_input(char c) override;

private:
    char rom_file[64];
    Window* my_window;
    
    // Internal Helper to load ROM
    void init_emulation();
};

#endif