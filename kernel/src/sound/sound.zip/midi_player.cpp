#include "midi_player.h"
#include "player_globals.h"
#include "../timer.h"
#include "../cppstd/stdio.h"
#include "../cppstd/string.h"
#include "../input.h"
#include "../memory/heap.h"
#include "../drv/pcspeaker/pcspeaker.h"
#include "../globals.h"

bool g_player_running = true;

static void player_input_handler(char c) {
    if (c == 27) g_player_running = false;
}

// Read variable length WITHOUT modifying pointer (for peeking)
static inline uint32_t peek_var_len(const uint8_t* p, const uint8_t* end) {
    uint32_t value = 0;
    uint8_t byte;
    do {
        if (p >= end) return 0;
        byte = *p++;
        value = (value << 7) | (byte & 0x7F);
    } while (byte & 0x80);
    return value;
}

// Read variable length AND advance pointer
static inline uint32_t read_var_len(const uint8_t*& p, const uint8_t* end) {
    uint32_t value = 0;
    uint8_t byte;
    do {
        if (p >= end) return 0;
        byte = *p++;
        value = (value << 7) | (byte & 0x7F);
    } while (byte & 0x80);
    return value;
}

static inline uint32_t read_be32(const uint8_t* p) { 
    return (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]; 
}

static inline uint16_t read_be16(const uint8_t* p) { 
    return (p[0] << 8) | p[1]; 
}

void play_midi(const uint8_t* data, uint32_t len, void* hda_driver_ignored, Synth* synth) {
    (void)hda_driver_ignored;
    g_player_running = true;
    set_input_handler(player_input_handler);

    if (g_renderer) g_renderer->clear(0x000000);
    
    printf("MIDI: Starting...\n");
    const uint8_t* ptr = data;
    const uint8_t* end_of_file = data + len;

    if (len < 14 || memcmp(ptr, "MThd", 4) != 0) { 
        printf("ERROR: Invalid MIDI\n"); 
        set_input_handler(nullptr);
        return; 
    }
    
    ptr += 4;
    uint32_t header_len = read_be32(ptr); ptr += 4;
    uint16_t format = read_be16(ptr); ptr += 2;
    uint16_t num_tracks = read_be16(ptr); ptr += 2;
    uint16_t division = read_be16(ptr); ptr += 2;
    if (header_len > 6) ptr += (header_len - 6);
    
    printf("MIDI: Format %u, %u tracks, %u ticks/qnote\n", format, num_tracks, division);
    
    // Find tracks
    const uint8_t* track_starts[16] = {nullptr};
    uint32_t track_lengths[16] = {0};
    int track_count = 0;
    
    while (ptr < end_of_file - 8 && track_count < 16) {
        if (memcmp(ptr, "MTrk", 4) == 0) {
            ptr += 4;
            uint32_t tlen = read_be32(ptr);
            ptr += 4;
            track_starts[track_count] = ptr;
            track_lengths[track_count] = tlen;
            printf("  Track %d: %u bytes\n", track_count, tlen);
            track_count++;
            ptr += tlen;
        } else {
            ptr++;
        }
    }
    
    if (track_count == 0) {
        printf("ERROR: No tracks\n");
        set_input_handler(nullptr);
        return;
    }
    
    // Extract tempo from first track
    uint32_t tempo_us_per_qnote = 500000;
    const uint8_t* t0 = track_starts[0];
    const uint8_t* t0_end = t0 + track_lengths[0];
    
    while (t0 < t0_end) {
        read_var_len(t0, t0_end);
        if (t0 >= t0_end) break;
        
        if (*t0 == 0xFF) {
            t0++;
            if (t0 >= t0_end) break;
            uint8_t mtype = *t0++;
            uint32_t mlen = read_var_len(t0, t0_end);
            
            if (mtype == 0x51 && mlen == 3 && t0 + 3 <= t0_end) {
                tempo_us_per_qnote = (t0[0] << 16) | (t0[1] << 8) | t0[2];
                printf("MIDI: Tempo = %u us/qnote\n", tempo_us_per_qnote);
                break;
            }
            t0 += mlen;
        } else {
            break;
        }
    }
    
    // Choose track to play
    int play_track_idx = (format == 1 && track_count > 1) ? 1 : 0;
    const uint8_t* track = track_starts[play_track_idx];
    const uint8_t* track_end = track + track_lengths[play_track_idx];
    
    printf("MIDI: Playing track %d\n", play_track_idx);
    
    // Fixed sample rate - use 44.1kHz for proper timing
    const uint32_t SAMPLE_RATE = 44100;
    
    // Calculate timing
    double us_per_midi_tick = (double)tempo_us_per_qnote / (double)division;
    double samples_per_midi_tick = ((double)SAMPLE_RATE * us_per_midi_tick) / 1000000.0;
    
    uint64_t cpu_freq = get_cpu_frequency();
    uint64_t cpu_ticks_per_sample = cpu_freq / SAMPLE_RATE;
    
    printf("MIDI: Sample rate %u Hz\n", SAMPLE_RATE);
    printf("MIDI: %.3f samples per MIDI tick\n", samples_per_midi_tick);
    printf("MIDI: %u CPU ticks per sample\n", (unsigned int)cpu_ticks_per_sample);
    
    pcspeaker_on();
    
    int instruments[16] = {0};
    uint8_t running_status = 0;
    uint32_t events_processed = 0;
    uint64_t next_sample_time = rdtsc_serialized();
    uint32_t sample_counter = 0;
    
    printf("MIDI: Starting playback...\n");
    
    while (g_player_running && track < track_end) {
        // Read delta time
        uint32_t delta_ticks = read_var_len(track, track_end);
        if (track >= track_end) {
            printf("MIDI: End of track after reading delta\n");
            break;
        }
        
        // Debug first 60 events
        if (events_processed < 60) {
            printf("Event %u: delta=%u ptr_offset=%u\n", 
                   events_processed, delta_ticks, (unsigned int)(track - data));
        }
        
        // Calculate samples to generate
        uint32_t samples_to_generate = (uint32_t)(delta_ticks * samples_per_midi_tick);
        
        // Generate audio for the delta time
        for (uint32_t s = 0; s < samples_to_generate && g_player_running; s++) {
            while (rdtsc_serialized() < next_sample_time && g_player_running) {
                if ((rdtsc_serialized() & 0x1FF) == 0) check_input_hooks();
                asm("pause");
            }
            
            if (!g_player_running) break;
            
            pcspeaker_set_data_bit(synth->get_mono_sample() > 0);
            next_sample_time += cpu_ticks_per_sample;
            sample_counter++;
            
            if (g_console && (sample_counter % 22050) == 0) {
                char buf[80];
                sprintf(buf, "Time: %us | Events: %u | RAM: %uKB",
                       (unsigned int)(sample_counter / SAMPLE_RATE),
                       events_processed,
                       (unsigned int)(heap_get_used() / 1024));
                g_console->putString(0, 0, buf, 0x00FFFF, 0x101030);
            }
        }
        
        if (!g_player_running) break;
        
        // Read status byte
        uint8_t status;
        if (*track & 0x80) {
            status = *track++;
            if (status >= 0x80 && status < 0xF0) {
                running_status = status;
            } else {
                running_status = 0; // System messages clear running status
            }
        } else {
            status = running_status;
            if (status == 0) {
                // Invalid - skip byte
                printf("MIDI: WARNING - Invalid running status at offset %u\n", 
                       (unsigned int)(track - data));
                track++;
                continue;
            }
        }
        
        if (track >= track_end) break;
        
        uint8_t type = status & 0xF0;
        uint8_t chan = status & 0x0F;
        
        // Process MIDI message
        if (type == 0x80 || type == 0x90 || type == 0xA0 || type == 0xB0 || type == 0xE0) {
            // 2 data bytes
            if (track + 2 > track_end) {
                printf("MIDI: ERROR - Unexpected end at 2-byte message\n");
                break;
            }
            uint8_t d1 = *track++;
            uint8_t d2 = *track++;
            
            if (type == 0x90 && d2 > 0) {
                synth->note_on(d1, d2, chan, instruments[chan]);
                events_processed++;
            } else if (type == 0x80 || (type == 0x90 && d2 == 0)) {
                synth->note_off(d1, chan);
                events_processed++;
            }
            
        } else if (type == 0xC0 || type == 0xD0) {
            // 1 data byte
            if (track >= track_end) {
                printf("MIDI: ERROR - Unexpected end at 1-byte message\n");
                break;
            }
            uint8_t d1 = *track++;
            
            if (type == 0xC0) {
                instruments[chan] = d1;
            }
            
        } else if (status == 0xFF) {
            // Meta event: FF <type> <length> <data>
            if (track >= track_end) break;
            uint8_t mtype = *track++;
            
            // Read length (this advances track pointer)
            uint32_t mlen = read_var_len(track, track_end);
            
            if (mtype == 0x51 && mlen == 3 && track + 3 <= track_end) {
                // Tempo change
                tempo_us_per_qnote = (track[0] << 16) | (track[1] << 8) | track[2];
                us_per_midi_tick = (double)tempo_us_per_qnote / (double)division;
                samples_per_midi_tick = ((double)SAMPLE_RATE * us_per_midi_tick) / 1000000.0;
                printf("MIDI: Tempo change to %u us/qnote\n", tempo_us_per_qnote);
            } else if (mtype == 0x2F) {
                // End of track
                track += mlen;
                printf("MIDI: End of track marker\n");
                break;
            }
            
            // Skip the data bytes
            track += mlen;
            if (track > track_end) {
                printf("MIDI: ERROR - Meta event extends past track end\n");
                track = track_end;
            }
            
        } else if (status == 0xF0 || status == 0xF7) {
            // SysEx: F0/F7 <length> <data>
            // CRITICAL: length does NOT include F0/F7 byte itself
            uint32_t slen = read_var_len(track, track_end);
            
            // Skip sysex data
            track += slen;
            if (track > track_end) {
                printf("MIDI: ERROR - SysEx extends past track end\n");
                track = track_end;
            }
            
        } else if (status >= 0xF1 && status <= 0xF6) {
            // System Common messages
            if (status == 0xF1 || status == 0xF3) {
                // 1 data byte
                if (track < track_end) track++;
            } else if (status == 0xF2) {
                // 2 data bytes
                if (track + 1 < track_end) track += 2;
                else track = track_end;
            }
            // F4, F5, F6 have no data bytes
        }
        
        // Generate one more sample at event time
        if (g_player_running && rdtsc_serialized() >= next_sample_time) {
            pcspeaker_set_data_bit(synth->get_mono_sample() > 0);
            next_sample_time += cpu_ticks_per_sample;
        }
    }
    
    // Let notes ring out for 1 second
    printf("MIDI: Finishing playback...\n");
    for (uint32_t i = 0; i < SAMPLE_RATE && g_player_running; i++) {
        while (rdtsc_serialized() < next_sample_time && g_player_running) {
            asm("pause");
        }
        pcspeaker_set_data_bit(synth->get_mono_sample() > 0);
        next_sample_time += cpu_ticks_per_sample;
    }

    pcspeaker_off();
    set_input_handler(nullptr);
    printf("MIDI: Done - %u events played\n", events_processed);
}