#ifndef SYNTH_H
#define SYNTH_H

#include <cstdint>
#include <cstddef>

#define AUDIO_SAMPLE_RATE 22050 // Lower sample rate for PC Speaker
#define AUDIO_CHANNELS 2      // Synth still generates stereo; we'll mix it down

enum Waveform {
    SQUARE,
    SAWTOOTH,
    SINE,
    KICK
};

struct Voice {
    bool active;
    int midi_note;
    int channel;
    float phase;
    float phase_inc;
    float amplitude;
    Waveform wave;
    
    // This member was missing from your header file.
    int32_t lifetime_samples; 

    Voice* next;
};

class Synth {
public:
    Synth(int sample_rate);
    ~Synth();

    void note_on(int note, int velocity, int channel, int instrument);
    void note_off(int note, int channel);
    
    // Generates a single mixed-down mono sample
    int16_t get_mono_sample();

private:
    Voice* active_voices;
    int sample_rate;
};

#endif