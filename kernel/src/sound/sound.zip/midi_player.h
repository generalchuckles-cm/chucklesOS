#ifndef MIDI_PLAYER_H
#define MIDI_PLAYER_H

// #include "../drv/hda/hda.h" // REMOVED: HDA driver no longer used
#include "synth.h"
#include <cstdint>
#include <cstddef> // Add for size_t

// The play_midi function no longer takes an IntelHDADriver*
void play_midi(const uint8_t* data, uint32_t len, void* /*hda_driver_ignored*/, Synth* synth);

#endif