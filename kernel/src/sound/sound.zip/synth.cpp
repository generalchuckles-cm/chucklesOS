#include "synth.h"
#include "../cppstd/math.h"
#include "../cppstd/string.h"
#include "../memory/heap.h"

static float midi_note_to_freq(int note) {
    return 440.0f * pow(2.0f, (float)(note - 69) / 12.0f);
}

Synth::Synth(int rate) : sample_rate(rate) {
    active_voices = nullptr;
}

Synth::~Synth() {
    Voice* current = active_voices;
    while (current != nullptr) {
        Voice* next = current->next;
        delete current;
        current = next;
    }
}

void Synth::note_on(int note, int velocity, int channel, int instrument) {
    Voice* new_voice = new Voice();
    
    new_voice->active = true;
    new_voice->midi_note = note;
    new_voice->channel = channel;
    new_voice->phase = 0.0f;
    new_voice->amplitude = (float)velocity / 127.0f;
    
    // Initialize lifetime to 2 seconds of samples.
    new_voice->lifetime_samples = sample_rate * 2;
    
    float freq = midi_note_to_freq(note);
    new_voice->phase_inc = (2.0f * PI * freq) / (float)sample_rate;

    if (channel == 9) {
        new_voice->wave = KICK;
    } else {
        switch(instrument) {
            case 0 ... 7: new_voice->wave = SQUARE; break;
            case 8 ... 15: new_voice->wave = SINE; break;
            case 16 ... 23: new_voice->wave = SQUARE; break;
            case 24 ... 31: new_voice->wave = SAWTOOTH; break;
            case 32 ... 39: new_voice->wave = SAWTOOTH; break;
            case 40 ... 55: new_voice->wave = SINE; break;
            case 56 ... 63: new_voice->wave = SQUARE; break;
            case 80 ... 87: new_voice->wave = SAWTOOTH; break;
            case 88 ... 95: new_voice->wave = SINE; break;
            default: new_voice->wave = SQUARE; break;
        }
    }

    new_voice->next = active_voices;
    active_voices = new_voice;
}

void Synth::note_off(int note, int channel) {
    for (Voice* v = active_voices; v != nullptr; v = v->next) {
        if (v->active && v->midi_note == note && v->channel == channel) {
            v->active = false;
            return;
        }
    }
}

int16_t Synth::get_mono_sample() {
    float sample = 0.0f;

    Voice* current = active_voices;
    Voice* prev = nullptr;

    while (current != nullptr) {
        // Decrement lifetime and check for expired or inactive notes
        current->lifetime_samples--;
        if (!current->active || current->lifetime_samples <= 0) {
            // Note has ended. Remove it from the list.
            Voice* to_delete = current;
            if (prev) {
                prev->next = current->next;
                current = current->next;
            } else {
                active_voices = current->next;
                current = current->next;
            }
            delete to_delete;
            continue;
        }

        // --- Synthesis ---
        float wave_val = 0.0f;
        switch(current->wave) {
            case SQUARE:
                wave_val = (current->phase < PI) ? 1.0f : -1.0f;
                break;
            case SAWTOOTH:
                wave_val = (current->phase / PI) - 1.0f;
                break;
            case SINE:
                wave_val = sin(current->phase);
                break;
            case KICK:
                wave_val = sin(current->phase) * (1.0f - (current->phase / (2.0f * PI)));
                if (current->phase >= 2.0f * PI) current->active = false;
                break;
        }
        sample += wave_val * current->amplitude;
        
        current->phase += current->phase_inc;
        if (current->phase >= 2.0f * PI) current->phase -= 2.0f * PI;

        prev = current;
        current = current->next;
    }
    
    sample /= 8.0f;
    if (sample > 1.0f) sample = 1.0f;
    if (sample < -1.0f) sample = -1.0f;

    return (int16_t)(sample * 32767.0f);
}