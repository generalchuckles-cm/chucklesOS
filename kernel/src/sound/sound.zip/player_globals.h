#ifndef PLAYER_GLOBALS_H
#define PLAYER_GLOBALS_H

// Declare g_player_running as an external variable.
// This tells any file that includes this header that the variable exists somewhere else.
#ifdef __cplusplus
extern "C" {
#endif

extern bool g_player_running;

#ifdef __cplusplus
}
#endif

#endif