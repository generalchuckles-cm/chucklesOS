#ifndef RENDER_H
#define RENDER_H

#include <limine.h>
#include <cstdint>

class Renderer {
public:
    Renderer(limine_framebuffer* framebuffer);

    void putPixel(int x, int y, std::uint32_t color);
    void drawRect(int x, int y, int w, int h, std::uint32_t color);
    void drawLine(int x0, int y0, int x1, int y1, std::uint32_t color);
    
    // New: Draw a filled circle
    void drawFilledCircle(int cx, int cy, int radius, std::uint32_t color);

    void clear(std::uint32_t color);

    void drawChar(int x, int y, char c, std::uint32_t color, int scale = 1);
    void drawString(int x, int y, const char* str, std::uint32_t color, int scale = 1);

    void renderBitmap(int x, int y, int w, int h, const std::uint8_t* data);
    void renderBitmapColored(int x, int y, int w, int h, const std::uint8_t* data, std::uint32_t color);

    std::uint32_t getWidth() const { return width; }
    std::uint32_t getHeight() const { return height; }
    limine_framebuffer* getFramebuffer() { return fb; }

private:
    limine_framebuffer* fb;
    std::uint32_t width;
    std::uint32_t height;
    std::uint32_t pitch;
    std::uint32_t bpp;
};

#endif