#ifndef PLAYER_GLOBALS_H
#define PLAYER_GLOBALS_H

#ifdef __cplusplus
extern "C" {
#endif

extern bool g_player_running;

#ifdef __cplusplus
}
#endif

#endif