#include "input.h"
#include "io.h"

static InputCallback g_current_handler = nullptr;
static void (*g_external_poller)() = nullptr;

bool g_shift_pressed = false;
bool g_ctrl_pressed = false;
bool g_using_interrupts = false;

// --- PS/2 Keyboard Maps (Set 1) ---

// Unshifted
static const char kbd_US_low [128] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',   
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',   
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',   
    0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,   
    '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   
    0, 0, 0, 0, '-', 0, 0, 0, '+', 0, 0, 0, 0, 0, 0, 0,   
    0, 0, 0, 0, 0, 0
};

// Shifted
static const char kbd_US_high [128] = {
    0,  27, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',   
    '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',   
    0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '\"', '~',   
    0, '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,   
    '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   
    0, 0, 0, 0, '-', 0, 0, 0, '+', 0, 0, 0, 0, 0, 0, 0,   
    0, 0, 0, 0, 0, 0
};

static char scancode_to_ascii(std::uint8_t code) {
    if (code == 0x48) return KEY_UP;
    if (code == 0x50) return KEY_DOWN;

    if (code > 128) return 0;

    if (g_shift_pressed) {
        return kbd_US_high[code];
    } else {
        return kbd_US_low[code];
    }
}

void set_input_handler(InputCallback handler) {
    g_current_handler = handler;
}

void input_register_poller(void (*callback)()) {
    g_external_poller = callback;
}

void input_inject_key(char c) {
    if (g_current_handler && c != 0) {
        g_current_handler(c);
    }
}

void input_process_scancode(uint8_t scancode) {
    if (scancode == 0x2A || scancode == 0x36) {
        g_shift_pressed = true;
        return;
    }
    if (scancode == 0xAA || scancode == 0xB6) {
        g_shift_pressed = false;
        return;
    }

    if (scancode == 0x1D) {
        g_ctrl_pressed = true;
        return;
    }
    if (scancode == 0x9D) {
        g_ctrl_pressed = false;
        return;
    }

    if (!(scancode & 0x80)) {
        char ascii = scancode_to_ascii(scancode);
        input_inject_key(ascii);
    }
}

void check_input_hooks() {
    // 1. Poll External Drivers (e.g. xHCI)
    if (g_external_poller) {
        g_external_poller();
    }

    // 2. Poll PS/2 Status Port (ONLY IF NOT USING INTERRUPTS)
    if (g_using_interrupts) return;

    if ((inb(0x64) & 1) == 0) {
        return;
    }

    // 3. Read PS/2 Data
    std::uint8_t scancode = inb(0x60);
    input_process_scancode(scancode);
}