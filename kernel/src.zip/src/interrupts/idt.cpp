#include "idt.h"
#include "pic.h"
#include "../render.h"
#include "../globals.h" 
#include "../cppstd/stdio.h"
#include "../cppstd/string.h"
#include "../drv/usb/xhci.h" 

struct IDTEntry {
    uint16_t offset_1; 
    uint16_t selector; 
    uint8_t  ist;      
    uint8_t  type_attr;
    uint16_t offset_2; 
    uint32_t offset_3; 
    uint32_t zero;     
} __attribute__((packed));

struct IDTPtr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static IDTEntry idt[256];
static IDTPtr idtr;

// Exceptions
extern "C" void isr0();
extern "C" void isr1();
extern "C" void isr2();
extern "C" void isr3();
extern "C" void isr4();
extern "C" void isr5();
extern "C" void isr6();
extern "C" void isr7();
extern "C" void isr8();
extern "C" void isr9();
extern "C" void isr10();
extern "C" void isr11();
extern "C" void isr12();
extern "C" void isr13();
extern "C" void isr14();
extern "C" void isr15();
extern "C" void isr16();
extern "C" void isr17();
extern "C" void isr18();
extern "C" void isr19();
extern "C" void isr20();
extern "C" void isr21();
extern "C" void isr22();
extern "C" void isr23();
extern "C" void isr24();
extern "C" void isr25();
extern "C" void isr26();
extern "C" void isr27();
extern "C" void isr28();
extern "C" void isr29();
extern "C" void isr30();
extern "C" void isr31();

// IRQs 0-15 (Vectors 32-47)
extern "C" void isr32();
extern "C" void isr33();
extern "C" void isr34();
extern "C" void isr35();
extern "C" void isr36();
extern "C" void isr37();
extern "C" void isr38();
extern "C" void isr39();
extern "C" void isr40();
extern "C" void isr41();
extern "C" void isr42();
extern "C" void isr43();
extern "C" void isr44();
extern "C" void isr45();
extern "C" void isr46();
extern "C" void isr47();

static void idt_set_gate(uint8_t num, void* base, uint16_t sel, uint8_t flags) {
    uint64_t addr = (uint64_t)base;
    idt[num].offset_1 = addr & 0xFFFF;
    idt[num].offset_2 = (addr >> 16) & 0xFFFF;
    idt[num].offset_3 = (addr >> 32) & 0xFFFFFFFF;
    idt[num].selector = sel;
    idt[num].ist = 0;
    idt[num].type_attr = flags;
    idt[num].zero = 0;
}

void idt_init() {
    idtr.limit = sizeof(idt) - 1;
    idtr.base = (uint64_t)&idt;
    memset(&idt, 0, sizeof(idt));

    uint16_t kernel_cs = 0x28; 

    // Exceptions
    idt_set_gate(0,  (void*)isr0,  kernel_cs, 0x8E);
    idt_set_gate(1,  (void*)isr1,  kernel_cs, 0x8E);
    idt_set_gate(2,  (void*)isr2,  kernel_cs, 0x8E);
    idt_set_gate(3,  (void*)isr3,  kernel_cs, 0x8E);
    idt_set_gate(4,  (void*)isr4,  kernel_cs, 0x8E);
    idt_set_gate(5,  (void*)isr5,  kernel_cs, 0x8E);
    idt_set_gate(6,  (void*)isr6,  kernel_cs, 0x8E);
    idt_set_gate(7,  (void*)isr7,  kernel_cs, 0x8E);
    idt_set_gate(8,  (void*)isr8,  kernel_cs, 0x8E);
    idt_set_gate(9,  (void*)isr9,  kernel_cs, 0x8E);
    idt_set_gate(10, (void*)isr10, kernel_cs, 0x8E);
    idt_set_gate(11, (void*)isr11, kernel_cs, 0x8E);
    idt_set_gate(12, (void*)isr12, kernel_cs, 0x8E);
    idt_set_gate(13, (void*)isr13, kernel_cs, 0x8E);
    idt_set_gate(14, (void*)isr14, kernel_cs, 0x8E);
    idt_set_gate(15, (void*)isr15, kernel_cs, 0x8E);
    idt_set_gate(16, (void*)isr16, kernel_cs, 0x8E);
    idt_set_gate(17, (void*)isr17, kernel_cs, 0x8E);
    idt_set_gate(18, (void*)isr18, kernel_cs, 0x8E);
    idt_set_gate(19, (void*)isr19, kernel_cs, 0x8E);
    idt_set_gate(20, (void*)isr20, kernel_cs, 0x8E);
    idt_set_gate(21, (void*)isr21, kernel_cs, 0x8E);
    idt_set_gate(22, (void*)isr22, kernel_cs, 0x8E);
    idt_set_gate(23, (void*)isr23, kernel_cs, 0x8E);
    idt_set_gate(24, (void*)isr24, kernel_cs, 0x8E);
    idt_set_gate(25, (void*)isr25, kernel_cs, 0x8E);
    idt_set_gate(26, (void*)isr26, kernel_cs, 0x8E);
    idt_set_gate(27, (void*)isr27, kernel_cs, 0x8E);
    idt_set_gate(28, (void*)isr28, kernel_cs, 0x8E);
    idt_set_gate(29, (void*)isr29, kernel_cs, 0x8E);
    idt_set_gate(30, (void*)isr30, kernel_cs, 0x8E);
    idt_set_gate(31, (void*)isr31, kernel_cs, 0x8E);

    // IRQs
    idt_set_gate(32, (void*)isr32, kernel_cs, 0x8E);
    idt_set_gate(33, (void*)isr33, kernel_cs, 0x8E);
    idt_set_gate(34, (void*)isr34, kernel_cs, 0x8E);
    idt_set_gate(35, (void*)isr35, kernel_cs, 0x8E);
    idt_set_gate(36, (void*)isr36, kernel_cs, 0x8E);
    idt_set_gate(37, (void*)isr37, kernel_cs, 0x8E);
    idt_set_gate(38, (void*)isr38, kernel_cs, 0x8E);
    idt_set_gate(39, (void*)isr39, kernel_cs, 0x8E); 
    idt_set_gate(40, (void*)isr40, kernel_cs, 0x8E);
    idt_set_gate(41, (void*)isr41, kernel_cs, 0x8E);
    idt_set_gate(42, (void*)isr42, kernel_cs, 0x8E);
    idt_set_gate(43, (void*)isr43, kernel_cs, 0x8E);
    idt_set_gate(44, (void*)isr44, kernel_cs, 0x8E);
    idt_set_gate(45, (void*)isr45, kernel_cs, 0x8E);
    idt_set_gate(46, (void*)isr46, kernel_cs, 0x8E);
    idt_set_gate(47, (void*)isr47, kernel_cs, 0x8E);

    asm volatile ("lidt %0" : : "m"(idtr));
    printf("IDT: Initialized.\n");
}

static const char* exception_messages[] = {
    "Division By Zero", "Debug", "NMI", "Breakpoint", "Overflow", "Bound Range", "Invalid Opcode", "No Device",
    "Double Fault", "Coprocessor Seg", "Bad TSS", "Segment Not Present", "Stack Fault", "GP Fault", "Page Fault", "Unknown",
    "x87 Fault", "Alignment Check", "Machine Check", "SIMD Fault", "Virtualization", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved", "Reserved", "Reserved", "Security", "Reserved"
};

extern "C" void exception_handler(InterruptFrame* frame) {
    asm volatile("cli");
    if (g_renderer) {
        g_renderer->clear(0x0000AA); 
        g_console->setColor(0xFFFFFF, 0x0000AA);
    }
    printf("\n\n  *** CHUCKLES OS KERNEL PANIC ***\n\n");
    if (frame->int_number < 32) {
        printf("  Exception: %s (Vector 0x%x)\n", exception_messages[frame->int_number], frame->int_number);
    } else {
        printf("  Exception: Unknown (Vector 0x%x)\n", frame->int_number);
    }
    printf("  Error Code: 0x%x\n  RIP: 0x%p\n", frame->error_code, frame->rip);
    if (frame->int_number == 14) {
        uint64_t cr2;
        asm volatile("mov %%cr2, %0" : "=r"(cr2));
        printf("  CR2: 0x%p\n", cr2);
    }
    printf("\n  System Halted.\n");
    while(1) asm volatile("hlt");
}

extern void ps2_irq_callback();

extern "C" void irq_handler(InterruptFrame* frame) {
    uint8_t irq = frame->int_number - 32;

    // Increment Global Stats
    if (irq < 16) {
        g_irq_counts[irq]++;
    }

    // Handle Spurious
    if (irq == 7) {
        pic_eoi(irq);
        return;
    }

    // Timer (IRQ 0) - Ignore EOI for now
    if (irq == 0) {
        pic_eoi(irq);
        return;
    }

    // LOG EVERYTHING ELSE (Passing frame->rip now!)
    if (g_sniffer_mode) {
        sniffer_log_irq(irq, frame->rip);
    }

    // Handle Keyboard Standard Logic
    if (irq == 1) {
        ps2_irq_callback();
    }

    // Handle xHCI Logic (Simple Poll on Interrupt)
    if (irq >= 10 && irq <= 15) {
        XhciDriver::getInstance().poll_events();
    }

    pic_eoi(irq);
}