#include "console.h"
#include "font.h" 
#include <limine.h>
#include <cstddef> 

extern "C" void *memcpy(void *dest, const void *src, std::size_t n);
extern "C" void *memset(void *s, int c, std::size_t n);

Console::Console(Renderer* r) : renderer(r), cursor_x(0), cursor_y(0), fgColor(0xFFFFFF), bgColor(0x000000), scale(1) {
    width_chars = renderer->getWidth() / (FONT_WIDTH * scale);
    height_chars = renderer->getHeight() / (FONT_HEIGHT * scale);
}

void Console::setColor(std::uint32_t fg, std::uint32_t bg) {
    fgColor = fg;
    bgColor = bg;
}

void Console::drawCursor(bool state) {
    // Draw a rectangle at the current cursor position
    // If state is true, use FG color (or a specific cursor color).
    // If state is false, use BG color to "erase" it.
    
    std::uint32_t color = state ? fgColor : bgColor;

    // Draw a block corresponding to the font size
    renderer->drawRect(
        cursor_x * FONT_WIDTH * scale, 
        cursor_y * FONT_HEIGHT * scale, 
        FONT_WIDTH * scale, 
        FONT_HEIGHT * scale, 
        color
    );
}

void Console::putString(int x_char, int y_char, const char* str, uint32_t fg, uint32_t bg) {
    int x_px = x_char * FONT_WIDTH * scale;
    int y_px = y_char * FONT_HEIGHT * scale;
    int len = 0;
    while(str[len]) len++;

    // Clear the background behind the text first
    renderer->drawRect(x_px, y_px, len * FONT_WIDTH * scale, FONT_HEIGHT * scale, bg);
    // Then draw the string itself
    renderer->drawString(x_px, y_px, str, fg, scale
    );
}

void Console::putChar(char c) {
    if (c == '\n') {
        newLine();
        return;
    }

    if (c == '\b') { 
        if (cursor_x > 0) {
            cursor_x--;
            renderer->drawRect(cursor_x * FONT_WIDTH * scale, 
                               cursor_y * FONT_HEIGHT * scale, 
                               FONT_WIDTH * scale, 
                               FONT_HEIGHT * scale, 
                               bgColor);
        }
        return;
    }

    renderer->drawChar(cursor_x * FONT_WIDTH * scale, 
                       cursor_y * FONT_HEIGHT * scale, 
                       c, fgColor, scale);

    cursor_x++;

    if (cursor_x >= width_chars) {
        newLine();
    }
}

void Console::print(const char* str) {
    while (*str) {
        putChar(*str++);
    }
}

void Console::newLine() {
    cursor_x = 0;
    cursor_y++;

    if (cursor_y >= height_chars) {
        scroll();
        cursor_y = height_chars - 1;
    }
}

void Console::scroll() {
    std::uint32_t* fb_addr = (std::uint32_t*)renderer->getFramebuffer()->address;
    std::uint64_t pitch = renderer->getFramebuffer()->pitch; 
    std::uint64_t total_height = renderer->getHeight();

    std::uint8_t* dest = (std::uint8_t*)fb_addr;
    // We only scroll from the second line (for the log), leaving the status bar at the top intact
    uint64_t scroll_start_y = FONT_HEIGHT * scale;
    dest += scroll_start_y * pitch;

    std::uint64_t row_byte_size = (FONT_HEIGHT * scale) * pitch;
    std::uint8_t* src = dest + row_byte_size;

    std::size_t bytes_to_move = (total_height * pitch) - (scroll_start_y * pitch) - row_byte_size;

    memcpy(dest, src, bytes_to_move);

    // Clear the last line of the console area
    std::uint64_t bottom_y = (height_chars - 1) * FONT_HEIGHT * scale;
    renderer->drawRect(0, bottom_y, renderer->getWidth(), FONT_HEIGHT * scale, bgColor);
}