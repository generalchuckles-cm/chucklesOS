#ifndef INPUT_H
#define INPUT_H

#include <cstdint>

// Special Key Definitions (Using high ASCII values)
#define KEY_UP    0x80
#define KEY_DOWN  0x81
#define KEY_CTRL  0x82

// Define the type of function that acts as the "Input Hook".
typedef void (*InputCallback)(char c);

// Register a function to handle input. 
void set_input_handler(InputCallback handler);

// The core "Mix-in" function called by the main loop/sleep.
void check_input_hooks();

// Global Modifier States
extern bool g_shift_pressed;
extern bool g_ctrl_pressed;
extern bool g_using_interrupts;

// --- New for xHCI & Interrupts ---

// Decodes a raw scancode (Set 1) and injects it. Used by Polling AND Interrupts.
void input_process_scancode(uint8_t scancode);

// Allows external drivers (USB) to push a character into the current handler
void input_inject_key(char c);

// Allows external drivers to register a polling function that runs in check_input_hooks
void input_register_poller(void (*callback)());

#endif