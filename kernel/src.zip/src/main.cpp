#include <cstdint>
#include <cstddef>
#include <limine.h>
#include "render.h"
#include "console.h"
#include "io.h"
#include "globals.h"
#include "cppstd/stdio.h"
#include "cppstd/string.h"
#include "timer.h"
#include "input.h" 
#include "boot_image.h"
#include "3dengine/engine.h" 
#include "dvd.h" 
#include "stress/stress.h" 
#include "pci/pci.h"
#include "pci/lspci.h"
#include "memory/pmm.h"
#include "memory/vmm.h"
#include "memory/heap.h"
#include "drv/gpu/scangpu.h"
#include "drv/gpu/intel_gpu.h" 
#include "interrupts/idt.h"
#include "interrupts/pic.h"
#include "drv/ps2/ps2_kbd.h"
#include "drv/pcspeaker/pcspeaker.h" 
#include "sound/midi_player.h"
#include "drv/usb/xhci.h" 

// --- Global Pointers ---
Console* g_console = nullptr;
Renderer* g_renderer = nullptr;

// --- Sniffer State ---
bool g_sniffer_mode = false;
volatile bool g_sniffer_dirty = false;
uint64_t g_irq_counts[16] = {0};
const char* g_irq_names[16] = {
    "Timer", "Keyboard", "Cascade", "COM2", 
    "COM1", "LPT2", "Floppy", "LPT1/Spur", 
    "CMOS", "Free", "Free", "Free", 
    "Mouse", "FPU", "ATA-Pri", "ATA-Sec"
};
int g_xhci_irq_line = -1;

// --- Sniffer Buffer ---
#define SNIFFER_LINES 12
#define SNIFFER_LEN 100
char sniffer_buffer[SNIFFER_LINES][SNIFFER_LEN];
int sniffer_head = 0;

void sniffer_log_irq(int irq, uint64_t rip) {
    const char* name = (irq == g_xhci_irq_line) ? "xHCI USB" : g_irq_names[irq];
    sprintf(sniffer_buffer[sniffer_head], "[%d] IRQ %d (%s) RIP: 0x%x", (int)(rdtsc_serialized() / 1000000), irq, name, rip);
    sniffer_head = (sniffer_head + 1) % SNIFFER_LINES;
    g_sniffer_dirty = true;
}

// NEW: Generic logger for driver events (like xHCI polling)
void sniffer_log_custom(const char* message) {
    sprintf(sniffer_buffer[sniffer_head], "[%d] %s", (int)(rdtsc_serialized() / 1000000), message);
    sniffer_head = (sniffer_head + 1) % SNIFFER_LINES;
    g_sniffer_dirty = true;
}

void render_sniffer_overlay() {
    if (!g_renderer) return;
    
    int w = g_renderer->getWidth();
    int h = g_renderer->getHeight();
    int panel_h = 240;
    int y_start = h - panel_h;
    
    // Draw Background
    g_renderer->drawRect(0, y_start, w, panel_h, 0x000022); 
    g_renderer->drawLine(0, y_start, w, y_start, 0xFFFFFF);
    g_renderer->drawString(10, y_start + 5, "--- INTERRUPT ANALYZER ---", 0x00FF00);

    // Left Column: Rolling Log
    g_renderer->drawString(10, y_start + 25, "Event Log:", 0xAAAAAA);
    int y = y_start + 45;
    for (int i = 0; i < SNIFFER_LINES; i++) {
        int read_idx = (sniffer_head + i) % SNIFFER_LINES;
        if (sniffer_buffer[read_idx][0] != 0) {
            g_renderer->drawString(10, y, sniffer_buffer[read_idx], 0xFFFFFF);
            y += 16;
        }
    }

    // Right Column: Statistics
    int col2_x = w / 2;
    g_renderer->drawLine(col2_x - 10, y_start + 25, col2_x - 10, h - 10, 0x555555);
    g_renderer->drawString(col2_x, y_start + 25, "IRQ Statistics:", 0xAAAAAA);
    
    y = y_start + 45;
    for (int i = 0; i < 8; i++) {
        char buf[64];
        // IRQ 0-7
        sprintf(buf, "IRQ %d (%s): %u", i, (i == g_xhci_irq_line) ? "xHCI USB" : g_irq_names[i], (uint32_t)g_irq_counts[i]);
        g_renderer->drawString(col2_x, y, buf, g_irq_counts[i] > 0 ? 0xFFFF00 : 0x666666);
        
        // IRQ 8-15
        int j = i + 8;
        sprintf(buf, "IRQ %d (%s): %u", j, (j == g_xhci_irq_line) ? "xHCI USB" : g_irq_names[j], (uint32_t)g_irq_counts[j]);
        g_renderer->drawString(col2_x + 200, y, buf, g_irq_counts[j] > 0 ? 0xFFFF00 : 0x666666);
        
        y += 16;
    }
    
    g_sniffer_dirty = false;
}

namespace {
    __attribute__((used, section(".limine_requests")))
    volatile std::uint64_t limine_base_revision[] = LIMINE_BASE_REVISION(2);

    __attribute__((used, section(".limine_requests")))
    volatile struct limine_framebuffer_request framebuffer_request = {
        .id = LIMINE_FRAMEBUFFER_REQUEST_ID, .revision = 0, .response = nullptr
    };

    __attribute__((used, section(".limine_requests")))
    volatile struct limine_executable_cmdline_request cmdline_request = {
        .id = LIMINE_EXECUTABLE_CMDLINE_REQUEST_ID, .revision = 0, .response = nullptr
    };

    __attribute__((used, section(".limine_requests_start")))
    volatile std::uint64_t limine_requests_start_marker[] = LIMINE_REQUESTS_START_MARKER;

    __attribute__((used, section(".limine_requests_end")))
    volatile std::uint64_t limine_requests_end_marker[] = LIMINE_REQUESTS_END_MARKER;
}

namespace {
    void hcf() { for (;;) { asm ("hlt"); } }
}

// --- C++ ABI Stubs ---
extern "C" {
    int __cxa_atexit(void (*)(void *), void *, void *) { return 0; }
    void __cxa_pure_virtual() { hcf(); }
    void *__dso_handle;

    int __cxa_guard_acquire(int64_t *guard) {
        volatile char *initialized = (volatile char *)guard;
        return *initialized == 0;
    }

    void __cxa_guard_release(int64_t *guard) {
        volatile char *initialized = (volatile char *)guard;
        *initialized = 1;
    }
}

extern void (*__init_array[])();
extern void (*__init_array_end[])();

// --- Shell State ---
char input_buffer[256];
int input_index = 0;
#define HISTORY_MAX 256
char cmd_history[HISTORY_MAX][256];
int history_count = 0;    
int history_view_idx = 0; 
bool g_cursor_visible = false;
uint64_t g_last_blink_tick = 0;
uint64_t g_blink_interval = 0; 

// --- Helpers ---
static void enable_sse() {
    uint64_t cr0, cr4;
    asm volatile ("mov %%cr0, %0" : "=r"(cr0));
    cr0 &= ~(1 << 2); cr0 |= (1 << 1);  
    asm volatile ("mov %0, %%cr0" :: "r"(cr0));
    asm volatile ("mov %%cr4, %0" : "=r"(cr4));
    cr4 |= (3 << 9);  
    asm volatile ("mov %0, %%cr4" :: "r"(cr4));
}

static int atoi(const char* str) {
    int res = 0;
    while (*str >= '0' && *str <= '9') { res = res * 10 + (*str - '0'); str++; }
    return res;
}

bool check_cmdline(const char* flag) {
    if (!cmdline_request.response || !cmdline_request.response->cmdline) return false;
    const char* cmd = cmdline_request.response->cmdline;
    int len = strlen(flag);
    while (*cmd) {
        if (memcmp(cmd, flag, len) == 0) {
            char next = *(cmd + len);
            if (next == ' ' || next == 0) return true;
        }
        cmd++;
    }
    return false;
}

void replace_input_line(const char* new_str) {
    while (input_index > 0) { printf("\b"); input_index--; }
    memset(input_buffer, 0, sizeof(input_buffer));
    int len = 0;
    while (new_str[len]) {
        input_buffer[len] = new_str[len];
        printf("%c", new_str[len]);
        len++;
    }
    input_index = len;
}

// Wrapper for the Xhci Poll
static void usb_poll_wrapper() {
    XhciDriver::getInstance().poll_events();
}

void shell_input_handler(char c) {
    g_cursor_visible = true;
    if (g_console) g_console->drawCursor(false); 
    g_last_blink_tick = rdtsc_serialized();      

    if (g_ctrl_pressed && (c == 'p' || c == 'P' || c == 16)) {
        set_input_handler(nullptr);
        lspci_run_detailed();
        
        printf("$ "); 
        if (input_index > 0) printf("%s", input_buffer);
        
        set_input_handler(shell_input_handler);
        return;
    }

    if (c == (char)KEY_UP) {
        if (history_count > 0) {
            if (history_view_idx == -1) history_view_idx = history_count - 1;
            else if (history_view_idx > 0) history_view_idx--;
            replace_input_line(cmd_history[history_view_idx]);
        }
        return;
    }
    if (c == (char)KEY_DOWN) {
        if (history_view_idx != -1) {
            history_view_idx++;
            if (history_view_idx >= history_count) {
                history_view_idx = -1;
                replace_input_line("");
            } else {
                replace_input_line(cmd_history[history_view_idx]);
            }
        }
        return;
    }

    if (c == '\n') {
        if (g_console) g_console->drawCursor(false);
        printf("\n");

        if (input_index > 0) {
            char history_entry[256];
            strcpy(history_entry, input_buffer);
            if (history_count < HISTORY_MAX) {
                strcpy(cmd_history[history_count], history_entry);
                history_count++;
            } else {
                for (int i = 0; i < HISTORY_MAX - 1; i++) memcpy(cmd_history[i], cmd_history[i+1], 256);
                strcpy(cmd_history[HISTORY_MAX-1], history_entry);
            }
        }
        history_view_idx = -1; 

        char* argv[32];
        int argc = 0;
        bool in_token = false;
        for (int i = 0; input_buffer[i] != 0 && argc < 32; i++) {
            if (input_buffer[i] == ' ') { input_buffer[i] = 0; in_token = false; } 
            else if (!in_token) { argv[argc++] = &input_buffer[i]; in_token = true; }
        }
        argv[argc] = nullptr; 

        if (argc > 0) {
            if (strcmp(argv[0], "help") == 0) {
                printf("Available commands:\n  help, reboot, clear, sysinfo, lspci, free\n");
                printf("  3drnd [-s speed] [-f fps]\n");
                printf("  dvd   [-s speed] [-f fps]\n");
                printf("  playmidi\n");
                printf("  stress [-s speed]\n");
                printf("  usbinit (force xhci)\n");
            } 
            else if (strcmp(argv[0], "clear") == 0) {
                if (g_renderer) g_renderer->clear(0x000000);
            }
            else if (strcmp(argv[0], "reboot") == 0) outb(0x64, 0xFE);
            else if (strcmp(argv[0], "sysinfo") == 0) {
                if (g_renderer) printf("Res: %dx%d\n", g_renderer->getWidth(), g_renderer->getHeight());
                printf("CPU: %d MHz\n", (int)(get_cpu_frequency() / 1000000));
            }
            else if (strcmp(argv[0], "lspci") == 0) {
                set_input_handler(nullptr);
                lspci_run_detailed();
                set_input_handler(shell_input_handler);
            }
            else if (strcmp(argv[0], "free") == 0) heap_print_stats();
            else if (strcmp(argv[0], "stress") == 0) {
                uint64_t speed = 0;
                for (int i = 1; i < (argc - 1); i += 2) { if (strcmp(argv[i], "-s") == 0) speed = atoi(argv[i+1]); }
                set_input_handler(nullptr);
                if (g_renderer) run_stress_test(g_renderer, speed);
                set_input_handler(shell_input_handler);
            }
             else if (strcmp(argv[0], "dvd") == 0) {
                uint64_t speed = 0, fps = 60;
                for (int i = 1; i < (argc - 1); i += 2) {
                    if (strcmp(argv[i], "-s") == 0) speed = atoi(argv[i+1]);
                    else if (strcmp(argv[i], "-f") == 0) fps = atoi(argv[i+1]);
                }
                set_input_handler(nullptr);
                if (g_renderer) run_dvd_demo(g_renderer, speed, fps);
                set_input_handler(shell_input_handler);
            }
            else if (strcmp(argv[0], "3drnd") == 0) {
                uint64_t speed = 0, fps = 10;
                for (int i = 1; i < (argc - 1); i += 2) {
                    if (strcmp(argv[i], "-s") == 0) speed = atoi(argv[i+1]);
                    else if (strcmp(argv[i], "-f") == 0) fps = atoi(argv[i+1]);
                }
                set_input_handler(nullptr);
                if (g_renderer) run_3d_demo(g_renderer, speed, fps);
                set_input_handler(shell_input_handler);
            }
            else if (strcmp(argv[0], "playmidi") == 0) {
                play_midi(nullptr, 0, nullptr, nullptr); 
                set_input_handler(shell_input_handler);
            }
            else if (strcmp(argv[0], "usbinit") == 0) {
                 XhciDriver::getInstance().init(0x8086, 0x31a8);
                 input_register_poller(usb_poll_wrapper);
            }
            else printf("Unknown: %s\n", argv[0]);
        }
        memset(input_buffer, 0, sizeof(input_buffer));
        input_index = 0;
        printf("$ ");
    } 
    else if (c == '\b') {
        if (input_index > 0) {
            if (g_console) g_console->drawCursor(false); 
            input_index--; input_buffer[input_index] = 0; printf("\b");
        }
    }
    else if (input_index < 255) {
        if (g_console) g_console->drawCursor(false);
        input_buffer[input_index] = c; input_index++; input_buffer[input_index] = 0; printf("%c", c);
    }
}

extern "C" void kmain() {
    enable_sse();
    if (LIMINE_BASE_REVISION_SUPPORTED(limine_base_revision) == false) hcf();
    for (std::size_t i = 0; &__init_array[i] != __init_array_end; i++) __init_array[i]();
    if (framebuffer_request.response == nullptr || framebuffer_request.response->framebuffer_count < 1) hcf();

    limine_framebuffer *framebuffer = framebuffer_request.response->framebuffers[0];
    pmm_init(); vmm_init(); heap_init(); idt_init();

    Renderer renderer(framebuffer);
    Console console(&renderer);
    g_console = &console;
    g_renderer = &renderer;

    // --- SNIFFER MODE (Split Screen) ---
    if (check_cmdline("-sniffer")) {
        g_sniffer_mode = true;
        
        // Zero out log buffer
        for(int i=0; i<SNIFFER_LINES; i++) memset(sniffer_buffer[i], 0, SNIFFER_LEN);

        renderer.clear(0x000000);
        console.setColor(0x00FF00, 0x000000);
        printf("CHUCKLES OS: SNIFFER MODE ACTIVE\n");
        printf("Interrupts will appear in the blue box below.\n");
        printf("Initializing Hardware...\n");

        pic_init();
        
        // NO PS/2 init here to prevent Gemini Lake freeze
        
        if (XhciDriver::getInstance().init(0x8086, 0x31a8)) {
            PCIDevice dev;
            if (pci_find_device_by_class(0x0C, 0x03, &dev)) { 
                 g_xhci_irq_line = dev.irq_line;
            }
            printf("xHCI: Initialized (IRQ %d).\n", g_xhci_irq_line);
        } else {
            printf("xHCI: Failed.\n");
        }

        // Force initial render so the box appears
        g_sniffer_dirty = true;

        asm volatile ("sti");
        printf("System Running. Polling Events...\n");
        
        // POLLING LOOP FOR SNIFFER (Since IRQ 17 is out of reach)
        while(true) {
            // Manually check xHCI
            XhciDriver::getInstance().poll_events();
            
            if (g_sniffer_dirty) {
                render_sniffer_overlay();
            }
            
            sleep_ms(1);
        }
    } else {
        // Normal Boot Splash
        renderer.clear(0x000000);
        int bmp_x = (renderer.getWidth() - boot_image_WIDTH) / 2;
        int bmp_y = (renderer.getHeight() - boot_image_HEIGHT) / 2;
        renderer.renderBitmap(bmp_x, bmp_y, boot_image_WIDTH, boot_image_HEIGHT, g_boot_image_data);
        sleep_ticks(1000000000);
    }
    
    // --- CMDLINE PARSING (Normal) ---
    if (check_cmdline("-midi")) {
        renderer.clear(0x000000);
        console.setColor(0xFFFFFF, 0x000000);
        play_midi(nullptr, 0, nullptr, nullptr); 
        hcf();
    }
    if (check_cmdline("-ball")) { g_intel_gpu.init(); run_stress_test(&renderer, 0); }

    // Init shell state
    memset(input_buffer, 0, sizeof(input_buffer));
    input_index = 0;
    history_count = 0; history_view_idx = -1;

    if (!g_sniffer_mode) {
        renderer.clear(0x000000);
        console.setColor(0xFFFFFF, 0x000000);
        printf("System: ChucklesOSv3 Alpha 8\n");
        printf("Driver: Intel Gen9.5+\n");
        if (g_intel_gpu.init()) printf("GPU: Initialized.\n");
        else printf("GPU: Initialization Failed.\n");
    }
    
    // Check flags (only if not already sniffer)
    if (!g_sniffer_mode) {
        if (check_cmdline("-xhci")) {
            if (XhciDriver::getInstance().init(0x8086, 0x31a8)) input_register_poller(usb_poll_wrapper);
        }
        if (check_cmdline("-pci")) lspci_run_detailed(true);
        if (check_cmdline("-interrupt")) {
            printf("KERNEL: Enabling Interrupt Mode (PIC/IDT)...\n");
            g_using_interrupts = true;
            pic_init();
            ps2_init();
            asm volatile ("sti");
        }
    }

    if (!g_sniffer_mode) printf("$ ");

    g_blink_interval = get_cpu_frequency() / 2; 
    g_last_blink_tick = rdtsc_serialized();

    set_input_handler(shell_input_handler);

    while (true) {
        check_input_hooks();
        uint64_t now = rdtsc_serialized();
        
        // Blink Cursor (only in shell mode)
        if (!g_sniffer_mode && now - g_last_blink_tick > g_blink_interval) {
            g_cursor_visible = !g_cursor_visible;
            if (g_console) g_console->drawCursor(g_cursor_visible);
            g_last_blink_tick = now;
        }

        // Draw Sniffer Overlay if active AND DIRTY
        if (g_sniffer_mode && g_sniffer_dirty) {
            render_sniffer_overlay();
        }

        asm volatile ("pause");
    }
}